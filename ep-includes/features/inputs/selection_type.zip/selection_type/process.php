<?php
// if (!isset($seg)) exit;

const SEARCHABLE_FIELDS_LIMIT = 7;

/**
 * Formato 1: [field-id="{x}"]
 */
function searchable_fields_by_field_id($fieldId, string $searchValue): array
{
    $row   = get_result("SELECT `Query` FROM tb_cruds_fields WHERE " . safe_where('id', '=', $fieldId));
    $query = $row['Query'] ?? null;

    if (empty($query)) return [];

    return run_searchable_query($query, $searchValue, null);
}


/**
 * Formato 2: [field-search='{x}']
 */
function searchable_fields_by_group(string $key, string $searchValue): array
{
    $group = $GLOBALS['searchable-fields'][$key] ?? null;

    if (empty($group) || empty($group['query'])) return [];

    if (!empty($group['permission']))
    {
      $permission = load_permission($group['permission'], 'custom');
      if (!$permission) {return [];}
    }

    return run_searchable_query($group['query'], $searchValue, $group['fields'] ?? []);
}


/**
 * Executa a query base (adicionando a condição de busca e o limite de
 * registros) e normaliza o resultado para [ ['value' => ..., 'display' => ...], ... ].
 *
 * @param string     $baseQuery   SQL base, já selecionando "value" e "display".
 * @param string     $searchValue Texto digitado pelo usuário.
 * @param array|null $fields      Lista explícita de colunas pesquisáveis
 *                                (formato 2). Quando vazio/null, as colunas
 *                                são deduzidas a partir da expressão usada
 *                                como "display" na própria query (formato 1),
 *                                desmontando um CONCAT(...) quando existir.
 */
function run_searchable_query(string $baseQuery, string $searchValue, ?array $fields): array
{
    $sql = rtrim(trim($baseQuery), "; \t\n\r\0\x0B");

    if ($searchValue !== '')
    {
        $columns = !empty($fields) ? $fields : extract_display_columns($sql);

        if (!empty($columns))
        {
            $likeValue  = '%' . escape_like_wildcards($searchValue) . '%';

            // skip_sanitize=true: esses nomes de coluna vêm de configuração
            // do próprio CMS (tb_cruds_fields.Query ou $GLOBALS['searchable-fields']),
            // não da requisição, então podem conter qualificação de tabela
            // ("t.coluna"), que a sanitização padrão de safe_where() removeria.
            // O valor de busca continua escapado por safe_where()/db_escape().
            $conditions = array_map(
                fn($column) => safe_where($column, 'LIKE', $likeValue, true),
                $columns
            );

            $sql = inject_where_condition($sql, implode(' OR ', $conditions));
        }
    }

    // Sempre respeita o limite fixo de 7 registros, substituindo
    // qualquer LIMIT que a query base já possua.
    $sql = strip_trailing_limit($sql);
    $sql.= ' LIMIT ' . SEARCHABLE_FIELDS_LIMIT;

    $rows = get_results($sql) ?: [];

    return array_map(function ($row) {
        $row = (array) $row;
        return [
            'value'   => $row['value']   ?? null,
            'display' => $row['display'] ?? null,
        ];
    }, $rows);
}


/**
 * Insere a condição de busca respeitando um WHERE que a query já possa
 * ter: se já existir WHERE, adiciona " AND (...)"; caso contrário,
 * adiciona " WHERE (...)". Em ambos os casos, a condição é inserida
 * antes de um eventual ORDER BY / GROUP BY / HAVING / LIMIT já
 * existente na query base, e não depois dele.
 */
function inject_where_condition(string $sql, string $condition): string
{
    $hasWhere = (bool) preg_match('/\bwhere\b/i', $sql);
    $clause   = $hasWhere ? "AND ({$condition})" : "WHERE ({$condition})";

    if (preg_match('/\b(order\s+by|group\s+by|having|limit)\b/i', $sql, $m, PREG_OFFSET_CAPTURE))
    {
        $pos = $m[0][1];
        return rtrim(substr($sql, 0, $pos)) . " {$clause} " . substr($sql, $pos);
    }

    return rtrim($sql) . " {$clause}";
}


/**
 * Remove um LIMIT já existente ao final da query (se houver), para que
 * possamos aplicar o limite fixo de 7 registros sem gerar SQL inválido.
 */
function strip_trailing_limit(string $sql): string
{
    return preg_replace('/\s+limit\s+\d+(\s*,\s*\d+)?\s*$/i', '', rtrim($sql));
}


/**
 * Descobre quais colunas reais devem ser pesquisadas a partir da
 * expressão usada como "display" no SELECT da query base. Se a
 * expressão for um CONCAT(...)/CONCAT_WS(...), retorna cada campo
 * usado dentro dele (para permitir busca com OR em cada um); caso
 * contrário, retorna a própria expressão/coluna.
 */
function extract_display_columns(string $sql): array
{
    if (!preg_match('/select\s+(.*?)\s+from\s/is', $sql, $m)) {
        return [];
    }

    $columns = split_top_level_commas($m[1]);

    foreach ($columns as $column)
    {
        $column = trim($column);

        if (preg_match('/^(.*?)\s+as\s+display\s*$/i', $column, $mm)
            || preg_match('/^(.*?)\s+display\s*$/i', $column, $mm))
        {
            return extract_columns_from_expression(trim($mm[1]));
        }
    }

    return [];
}


/**
 * Dada uma expressão de SELECT (ex.: "first_name" ou
 * "CONCAT(first_name, ' ', last_name)"), retorna as colunas reais que
 * devem entrar na busca.
 */
function extract_columns_from_expression(string $expr): array
{
    if (preg_match('/^concat(_ws)?\s*\((.*)\)$/is', $expr, $m))
    {
        $isConcatWs = !empty($m[1]);
        $args = array_map('trim', split_top_level_commas($m[2]));

        // Em CONCAT_WS o primeiro argumento é o separador, não uma coluna.
        if ($isConcatWs) array_shift($args);

        $columns = [];
        foreach ($args as $arg)
        {
            // Ignora literais de texto/número usados só como separador.
            if (preg_match('/^\'.*\'$/s', $arg)) continue;
            if (preg_match('/^".*"$/s', $arg)) continue;
            if (is_numeric($arg)) continue;
            if ($arg === '') continue;

            $columns[] = $arg;
        }

        return $columns;
    }

    return [$expr];
}


/**
 * Divide uma lista separada por vírgulas (ex.: a lista de colunas de um
 * SELECT) ignorando vírgulas dentro de parênteses (funções como
 * CONCAT(...)) ou dentro de strings entre aspas.
 */
function split_top_level_commas(string $text): array
{
    $parts   = [];
    $buffer  = '';
    $depth   = 0;
    $inStr   = false;
    $strChar = '';

    $len = strlen($text);
    for ($i = 0; $i < $len; $i++)
    {
        $char = $text[$i];

        if ($inStr)
        {
            $buffer.= $char;
            if ($char === $strChar) $inStr = false;
            continue;
        }

        if ($char === "'" || $char === '"')
        {
            $inStr   = true;
            $strChar = $char;
            $buffer.= $char;
            continue;
        }

        if ($char === '(') { $depth++; $buffer.= $char; continue; }
        if ($char === ')') { $depth--; $buffer.= $char; continue; }

        if ($char === ',' && $depth === 0)
        {
            $parts[] = $buffer;
            $buffer  = '';
            continue;
        }

        $buffer.= $char;
    }

    if (trim($buffer) !== '') $parts[] = $buffer;

    return $parts;
}


/**
 * Escapa os curingas do LIKE (% e _) presentes no texto digitado pelo
 * usuário, para que sejam tratados como caracteres literais.
 */
function escape_like_wildcards(string $value): string
{
    return addcslashes($value, '%_');
}
